package com.example.javafxproject;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class ControllerSignUp {
    public void createFolder(){
        new File("username+passwords").mkdir();
        String fileName = "username+passwords\\" + "file" + ".txt";
        File file = new File(fileName);
    }
    public void readFile() throws IOException {
        String fileName = "username+passwords\\" + "file" + ".txt";
        File file = new File(fileName);
        if(file.exists()){
            System.out.println("File already exists");
        }
        else{
            file.createNewFile();
            System.out.println("File created");
        }
    }

    boolean checkData = true;
    public void addData() throws IOException {
        String fileName = "username+passwords\\" + "file" + ".txt";
        File file = new File(fileName);
        FileInputStream inputStream = new FileInputStream(file);
        byte[] info = new byte[inputStream.available()];
        String saveInfo = new String(info);
        inputStream.read(info);
        inputStream.close();


        ArrayList<String> information = new ArrayList<String>();

        try {
            BufferedReader buffReader = new BufferedReader(new FileReader(fileName));
            String checkLine = buffReader.readLine();

            while (checkLine != null) {
                if (checkLine.startsWith("Username: ")) {
                    String value = checkLine.substring("Username: ".length());
                    information.add(value);
                } else if (checkLine.startsWith("Password: ")) {
                    String value = checkLine.substring("Password: ".length());
                    information.add(value);
                }

                checkLine = buffReader.readLine();
            }

            buffReader.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        String[] arr = information.toArray(new String[information.size()]);

        boolean checkUsername = false;
        for(int i = 0; i < arr.length; i++) {
            if (arr[i].equals(usernameSignUpField2.getText())) {
                checkUsername = true;
            }
        }
        if(checkUsername){
            System.out.println("User already exists");
        }
        else {
            new RandomAccessFile("username+passwords\\" + "file" + ".txt", "rw").
                    writeBytes(new String(info) + "Username: " + usernameSignUpField2.getText() + "\nPassword: "
                            + passwordSignUpField2.getText() + "\nEmail: " + emailSignUp.getText() + "\n" + "\n");
            System.out.println("Information is written");
        }
    }

    public void checkData(){
        if(usernameSignUpField2.getText().equals(passwordSignUpField2.getText())){
            System.out.println("Username and password must be different");
            checkData = false;
        }
        else if(usernameSignUpField2.getText().length() >= 10 && passwordSignUpField2.getText().length() >= 10) {
            System.out.println("Username must have less than 10 characters");
            checkData = false;
        }

        else if(usernameSignUpField2.getText().length() >= 10 || passwordSignUpField2.getText().length() >= 10) {
            System.out.println("Username must have less than 10 characters");
            checkData = false;
        }

        else if(usernameSignUpField2.getText().equals("") || passwordSignUpField2.getText().equals("") || emailSignUp.getText().equals("")){
            System.out.println("Username, password or email is empty");
            checkData = false;
            }
        else if(!emailSignUp.getText().endsWith("@gmail.com")){
            System.out.println("Email is not correct");
            checkData = false;
        }
        else if(!radioMale.isSelected() && !radioFemale.isSelected() && !radioOther.isSelected()){
            System.out.println("Gender is not selected");
            checkData = false;
        }
        else{
            checkData = true;
        }
    }
    public void countLines() throws IOException {
        String fileName = "username+passwords\\" + "file" + ".txt";
        BufferedReader buffReader = new BufferedReader(new FileReader(fileName));
        int linesNum = 0;
        while (buffReader.readLine() != null) {
            linesNum += 1;
        }
        buffReader.close();

        System.out.println("Number of your lines are : " + (linesNum - 1));
    }

    public void logic(){
        boolean logic = false;
        for(int i = 0; i < usernameSignUpField2.getText().length(); i++){
            if(usernameSignUpField2.getText().equals(passwordSignUpField2.getText())){
                logic = true;
            }
        }

        if(logic){
            System.out.println("Password matched\n");
        }
        else if(usernameSignUpField2.getText().length() >= 10 || passwordSignUpField2.getText().length() >= 10){
            System.out.println("username/password incorrect\n");
        }
        else{
            System.out.println();
        }

    }

    public void showFXML2() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
        }



    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField emailSignUp;

    @FXML
    private Button loginInButton2;

    @FXML
    public PasswordField passwordSignUpField2;

    @FXML
    private Button signUpButton2;

    @FXML
    public TextField usernameSignUpField2;

    @FXML
    private RadioButton radioFemale;

    @FXML
    private RadioButton radioMale;

    @FXML
    private RadioButton radioOther;


    @FXML
    public void initialize() {
        ToggleGroup toggleChange = new ToggleGroup();
        radioMale.setToggleGroup(toggleChange);
        radioFemale.setToggleGroup(toggleChange);
        radioOther.setToggleGroup(toggleChange);

        signUpButton2.setOnAction(event -> {
            createFolder();

            try {
                readFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            checkData();

            if(checkData) {
                try {
                    addData();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }

            else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText("Error is found ! Try again");
                    alert.show();
            }


                try {
                    countLines();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                logic();


        });

        loginInButton2.setOnAction(event -> {
            loginInButton2.getScene().getWindow().hide();
            try {
                showFXML2();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

    }
}





package com.example.javafxproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Admin_Class {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button backAdmin;

    @FXML
    private Button loginInButton;

    @FXML
    private PasswordField passAdmin;

    @FXML
    private TextField userAdmin;

    @FXML
    public void initialize() {
        loginInButton.setOnAction(event -> {
            if (userAdmin.getText().equals("Admin") && passAdmin.getText().equals("admin")) {
                loginInButton.getScene().getWindow().hide();
                System.out.println("Success");
                Parent root3 = null;
                try {
                    root3 = FXMLLoader.load(getClass().getResource("newsFile.fxml"));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                Scene scene = new Scene(root3);
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();

            } else {
                System.out.println("Admin login failed");
            }

        });

        backAdmin.setOnAction(event -> {
            backAdmin.getScene().getWindow().hide();
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        });
    }
}

package com.example.javafxproject;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Forgotten {

    public void forgot() throws IOException {
        ArrayList<String> information = new ArrayList<String>();
        String fileName = "username+passwords\\" + "file" + ".txt";;

        try {
            BufferedReader buffReader = new BufferedReader(new FileReader(fileName));
            String checkLine = buffReader.readLine();

            while (checkLine != null) {
                if (checkLine.startsWith("Username: ")) {
                    String value = checkLine.substring("Username: ".length());
                    information.add(value);
                } else if (checkLine.startsWith("Password: ")) {
                    String value = checkLine.substring("Password: ".length());
                    information.add(value);
                }

                checkLine = buffReader.readLine();
            }

            buffReader.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        String[] arr = information.toArray(new String[information.size()]);

        boolean forgotttt = false;
        for(int i = 0; i < arr.length; i++) {
            if (usernameForgot.getText().equals(arr[i])) {
                arr[i + 1] = newPassword.getText();
                forgotttt = true;
            }
        }
        if(forgotttt && !newPassword.getText().equals("")) {
            FileWriter fileWriter = new FileWriter(fileName);
            fileWriter.write("Username: " + usernameForgot.getText() + "\n");
            fileWriter.write("Password: " + newPassword.getText() + "\n");
            fileWriter.close();
        }

            else{
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("Incorrect login or empty password");
                alert.show();
            }
        }







    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button backForgot;

    @FXML
    private PasswordField newPassword;

    @FXML
    private Button resetButton;

    @FXML
    private TextField usernameForgot;

    @FXML
    public void initialize() {
        backForgot.setOnAction(event -> {
            backForgot.getScene().getWindow().hide();
            Parent root50 = null;
            try {
                root50 = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Scene scene = new Scene(root50);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        });

        resetButton.setOnAction(event -> {
            try {
                forgot();
                System.out.println("Your password has been changed !");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        });
    }
}

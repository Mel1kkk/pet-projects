package com.example.javafxproject;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class Admin_Class {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button loginInButton;

    @FXML
    private PasswordField passAdmin;

    @FXML
    private TextField userAdmin;

    @FXML
    void initialize() {
        loginInButton.setOnAction(event -> {
            if (userAdmin.getText().equals("Admin") && passAdmin.getText().equals("admin")) {
                System.out.println("Success");
            } else {
                System.out.println("no");
            }

        });
    }
}

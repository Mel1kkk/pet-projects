package com.example.javafxproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class NewsHomePage {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button bussinessButton;

    @FXML
    private Button economyButton;

    @FXML
    private Button sportsButton;

    @FXML
    private Button techButton;

    @FXML
    void initialize() {
        techButton.setOnAction(event -> {
            Menu techBar = new Menu("Technology");
            MenuItem bioTech = new MenuItem("Biotechnology");
            MenuItem aiTech = new MenuItem("Artificial Intelligence");
            MenuItem compTech = new MenuItem("Computers");
            techBar.getItems().addAll(bioTech, aiTech, compTech);

            Menu sportBar = new Menu("Sports");
            MenuItem basketSport = new MenuItem("Basketball");
            MenuItem volleySport = new MenuItem("Volleyball");
            MenuItem footSport = new MenuItem("Football");
            sportBar.getItems().addAll(basketSport, volleySport, footSport);

            Menu bussBar = new Menu("Business");
            MenuItem busIS = new MenuItem("Informational Systems");
            MenuItem busCorpo = new MenuItem("Corporations");
            MenuItem busParnet = new MenuItem("Partners");
            bussBar.getItems().addAll(busIS, busCorpo, busParnet);

            Menu economyBar = new Menu("Economy");
            MenuItem moneyEco = new MenuItem("Save money");
            MenuItem tradiEco = new MenuItem("Traditional");
            MenuItem marketEco = new MenuItem("Marketing");
            economyBar.getItems().addAll(moneyEco, tradiEco, marketEco);

            MenuBar menuBar = new MenuBar();
            menuBar.getMenus().addAll(techBar, sportBar, bussBar, economyBar);

            VBox vbox = new VBox();
            vbox.getChildren().add(menuBar);

            Scene scene = new Scene(vbox, 400, 300);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.setTitle("Menu Bar");
            stage.show();
    });

        sportsButton.setOnAction(event -> {
            Menu techBar = new Menu("Technology");
            MenuItem bioTech = new MenuItem("Biotechnology");
            MenuItem aiTech = new MenuItem("Artificial Intelligence");
            MenuItem compTech = new MenuItem("Computers");
            techBar.getItems().addAll(bioTech, aiTech, compTech);

            Menu sportBar = new Menu("Sports");
            MenuItem basketSport = new MenuItem("Basketball");
            MenuItem volleySport = new MenuItem("Volleyball");
            MenuItem footSport = new MenuItem("Football");
            sportBar.getItems().addAll(basketSport, volleySport, footSport);

            Menu bussBar = new Menu("Business");
            MenuItem busIS = new MenuItem("Informational Systems");
            MenuItem busCorpo = new MenuItem("Corporations");
            MenuItem busParnet = new MenuItem("Partners");
            bussBar.getItems().addAll(busIS, busCorpo, busParnet);

            Menu economyBar = new Menu("Economy");
            MenuItem moneyEco = new MenuItem("Save money");
            MenuItem tradiEco = new MenuItem("Traditional");
            MenuItem marketEco = new MenuItem("Marketing");
            economyBar.getItems().addAll(moneyEco, tradiEco, marketEco);

            MenuBar menuBar = new MenuBar();
            menuBar.getMenus().addAll(techBar, sportBar, bussBar, economyBar);

            VBox vbox = new VBox();
            vbox.getChildren().add(menuBar);

            Scene scene = new Scene(vbox, 400, 300);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.setTitle("Menu Bar");
            stage.show();
        });

        bussinessButton.setOnAction(event -> {
            Menu techBar = new Menu("Technology");
            MenuItem bioTech = new MenuItem("Biotechnology");
            MenuItem aiTech = new MenuItem("Artificial Intelligence");
            MenuItem compTech = new MenuItem("Computers");
            techBar.getItems().addAll(bioTech, aiTech, compTech);

            Menu sportBar = new Menu("Sports");
            MenuItem basketSport = new MenuItem("Basketball");
            MenuItem volleySport = new MenuItem("Volleyball");
            MenuItem footSport = new MenuItem("Football");
            sportBar.getItems().addAll(basketSport, volleySport, footSport);

            Menu bussBar = new Menu("Business");
            MenuItem busIS = new MenuItem("Informational Systems");
            MenuItem busCorpo = new MenuItem("Corporations");
            MenuItem busParnet = new MenuItem("Partners");
            bussBar.getItems().addAll(busIS, busCorpo, busParnet);

            Menu economyBar = new Menu("Economy");
            MenuItem moneyEco = new MenuItem("Save money");
            MenuItem tradiEco = new MenuItem("Traditional");
            MenuItem marketEco = new MenuItem("Marketing");
            economyBar.getItems().addAll(moneyEco, tradiEco, marketEco);

            MenuBar menuBar = new MenuBar();
            menuBar.getMenus().addAll(techBar, sportBar, bussBar, economyBar);

            VBox vbox = new VBox();
            vbox.getChildren().add(menuBar);

            Scene scene = new Scene(vbox, 400, 300);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.setTitle("Menu Bar");
            stage.show();
        });

        economyButton.setOnAction(event -> {
            Menu techBar = new Menu("Technology");
            MenuItem bioTech = new MenuItem("Biotechnology");
            MenuItem aiTech = new MenuItem("Artificial Intelligence");
            MenuItem compTech = new MenuItem("Computers");
            techBar.getItems().addAll(bioTech, aiTech, compTech);

            Menu sportBar = new Menu("Sports");
            MenuItem basketSport = new MenuItem("Basketball");
            MenuItem volleySport = new MenuItem("Volleyball");
            MenuItem footSport = new MenuItem("Football");
            sportBar.getItems().addAll(basketSport, volleySport, footSport);

            Menu bussBar = new Menu("Business");
            MenuItem busIS = new MenuItem("Informational Systems");
            MenuItem busCorpo = new MenuItem("Corporations");
            MenuItem busParnet = new MenuItem("Partners");
            bussBar.getItems().addAll(busIS, busCorpo, busParnet);

            Menu economyBar = new Menu("Economy");
            MenuItem moneyEco = new MenuItem("Save money");
            MenuItem tradiEco = new MenuItem("Traditional");
            MenuItem marketEco = new MenuItem("Marketing");
            economyBar.getItems().addAll(moneyEco, tradiEco, marketEco);

            MenuBar menuBar = new MenuBar();
            menuBar.getMenus().addAll(techBar, sportBar, bussBar, economyBar);

            VBox vbox = new VBox();
            vbox.getChildren().add(menuBar);

            Scene scene = new Scene(vbox, 400, 300);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.setTitle("Menu Bar");
            stage.show();
        });
    }



}

package com.example.javafxproject;

import javafx.fxml.*;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;

import java.io.*;
import java.net.StandardSocketOptions;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class HelloController {
    public void loginUp() throws IOException {
        ArrayList<String> information = new ArrayList<String>();
        String fileName = "username+passwords\\" + "file" + ".txt";;

        try {
            BufferedReader buffReader = new BufferedReader(new FileReader(fileName));
            String checkLine = buffReader.readLine();

            while (checkLine != null) {
                if (checkLine.startsWith("Username: ")) {
                    String value = checkLine.substring("Username: ".length());
                    information.add(value);
                } else if (checkLine.startsWith("Password: ")) {
                    String value = checkLine.substring("Password: ".length());
                    information.add(value);
                }

                checkLine = buffReader.readLine();
            }

            buffReader.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        String[] arr = information.toArray(new String[information.size()]);

        boolean check = false;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].equals(usernameField.getText()) && arr[i+1].equals(passwordField.getText())) {
                check = true;
                break;
            }
        }
        if (check) {
            System.out.println("You are welcome to read the news");
            loginInButton.getScene().getWindow().hide();
            Parent root = FXMLLoader.load(getClass().getResource("newsFile.fxml"));
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        }

        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Incorrect user or password, try again !");
            alert.show();
        }
    }


    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button adminButton;

    @FXML
    private Hyperlink forgotPassword;

    @FXML
    private Button loginInButton;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button signUpButton;

    @FXML
    private TextField usernameField;


    @FXML
    public void initialize() {        //Controller for Login
        signUpButton.setOnAction(event -> {
            signUpButton.getScene().getWindow().hide();

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation((getClass().getResource("/com/example/javafxproject/SignUp.fxml")));

            try {
                loader.load();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.showAndWait();
        });

        loginInButton.setOnAction(event -> {
            try {
                loginUp();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        });

        adminButton.setOnAction(event -> {
            adminButton.getScene().getWindow().hide();
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("adminFx.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        });
    }
}


